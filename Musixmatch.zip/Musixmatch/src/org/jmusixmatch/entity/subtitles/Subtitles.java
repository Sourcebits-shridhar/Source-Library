package org.jmusixmatch.entity.subtitles;

import com.google.gson.annotations.SerializedName;

/**
 * 
 * 
 * 
 * @version 1.0
 */
public class Subtitles {
	public String getSubtitle_body() {
		return subtitle_body;
	}

	public void setSubtitle_body(String subtitle_body) {
		this.subtitle_body = subtitle_body;
	}

	public String getLyricsCopyright() {
		return lyrics_copyright;
	}

	public void setLyricsCopyright(String lyrics_copyright) {
		this.lyrics_copyright = lyrics_copyright;
	}

	public int getSubtitle_Id() {
		return subtitle_id;
	}

	public void setSubtitle_Id(int subtitle_id) {
		this.subtitle_id = subtitle_id;
	}

	public String getSubtitles_language() {
		return subtitles_language;
	}

	public void setSubtitles_language(String subtitles_language) {
		this.subtitles_language = subtitles_language;
	}

	public String getPixel_tracking_url() {
		return pixel_tracking_url;
	}

	public void setPixel_tracking_url(String pixel_tracking_url) {
		this.pixel_tracking_url = pixel_tracking_url;
	}

	public int getRestricted() {
		return restricted;
	}

	public void setRestricted(int restricted) {
		this.restricted = restricted;
	}

	public String getScript_tracking_url() {
		return script_tracking_url;
	}

	public void setScript_tracking_url(String script_tracking_url) {
		this.script_tracking_url = script_tracking_url;
	}

	public String getHtml_tracking_url() {
		return html_tracking_url;
	}

	public void setHtml_tracking_url(String html_tracking_url) {
		this.html_tracking_url = html_tracking_url;
	}

	@SerializedName("subtitles_body")
	private String subtitle_body;

	@SerializedName("lyrics_copyright")
	private String lyrics_copyright;

	@SerializedName("subtitle_id")
	private int subtitle_id;

	@SerializedName("subtitles_language")
	private String subtitles_language;

	@SerializedName("pixel_tracking_url")
	private String pixel_tracking_url;

	@SerializedName("restricted")
	private int restricted;

	@SerializedName("script_tracking_url")
	private String script_tracking_url;

	@SerializedName("html_tracking_url")
	private String html_tracking_url;

	public String getScriptTrackingURL() {

		return script_tracking_url;
	}

	public String getPixelTrackingURL() {

		return pixel_tracking_url;
	}

}