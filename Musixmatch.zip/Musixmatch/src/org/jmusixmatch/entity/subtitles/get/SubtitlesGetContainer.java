package org.jmusixmatch.entity.subtitles.get;

import org.jmusixmatch.entity.Header;
import org.jmusixmatch.entity.subtitles.get.SubtitlesGetBody;

import com.google.gson.annotations.SerializedName;

public class SubtitlesGetContainer {
    @SerializedName("body")
    private SubtitlesGetBody body;
    
    @SerializedName("header")
    private Header header;

    public Header getHeader() {
        return header;
    }

    public void setHeader(Header header) {
        this.header = header;
    }

    public void setBody(SubtitlesGetBody body) {
        this.body = body;
    }

	public SubtitlesGetBody getBody() {
		
		return body;
	}

}


