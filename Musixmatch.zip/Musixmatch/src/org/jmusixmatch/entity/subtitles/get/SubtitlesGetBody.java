package org.jmusixmatch.entity.subtitles.get;

import com.google.gson.annotations.SerializedName;

import org.jmusixmatch.entity.subtitles.Subtitles;

public class SubtitlesGetBody {
	
    @SerializedName("subtitles")
    private Subtitles subtitle;

	public Subtitles getSubtitles() {
		return subtitle;
	}

	public void setSubtitles(Subtitles subtitle) {
		this.subtitle = subtitle;
	}

}