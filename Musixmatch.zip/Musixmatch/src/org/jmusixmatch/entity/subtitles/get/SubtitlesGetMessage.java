package org.jmusixmatch.entity.subtitles.get;

public class SubtitlesGetMessage {

	public Message message;

	public class Message {

		public Header header;
		public SubTitleBody body;
	}

	public class Subtitle {

		public String subtitle_id;
		public String restricted;
		public String subtitle_body;
		public String subtitle_language;
		public String script_tracking_url;
		public String pixel_tracking_url;
		public String html_tracking_url;
		public String lyrics_copyright;
		public String updated_time;
		public String subtitle_length;
	}

	public class SubTitleBody {
		public Subtitle subtitle;
	}

	class Header {
		public String status_code;
		public String execute_time;
	}

}