package org.jmusixmatch.entity.lyrics.get;

import com.google.gson.annotations.SerializedName;

import org.jmusixmatch.entity.lyrics.Lyrics;
import org.jmusixmatch.entity.subtitles.Subtitles;

public class LyricsGetBody {
	
    @SerializedName("lyrics")
    private Lyrics lyrics;

    public void setLyrics(Lyrics lyrics) {
        this.lyrics = lyrics;
    }

    public Lyrics getLyrics() {
        return lyrics;
    }

	public Subtitles getTrack_subtitle() {
		// TODO Auto-generated method stub
		return null;
	}
}
