package org.jmusixmatch;



import java.util.List;

import org.jmusixmatch.entity.lyrics.Lyrics;

import org.jmusixmatch.entity.subtitles.Subtitles;
import org.jmusixmatch.entity.subtitles.get.SubtitlesGetMessage.Subtitle;
import org.jmusixmatch.entity.track.Track;
import org.jmusixmatch.entity.track.TrackData;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.shridhar.music.R;

public class MusixmatchActivity extends Activity {
	
	TrackData data = null;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        String apiKey = "a7141f2a9c319314ce1ee22f589edeed";
        MusixMatch musixMatch = new MusixMatch(apiKey);            
        
        String trackName = "In da Club";
        String artistName = "50 cent";


        // Track Search [ Fuzzy ]
        Track track;
		try {
			Log.d("MATCH", "before get matching track");
			track = musixMatch.getMatchingTrack(trackName, artistName);
			Log.d("MATCH", "before get track");
			data = track.getTrack();

			Log.d("MATCH", "after get track");

			 Log.d("TEST", "AlbumID : "    + data.getAlbumId());
			 Log.d("TEST", "Album Name : " + data.getAlbumName());
			 Log.d("TEST", "Artist ID : "  + data.getArtistId());
			 Log.d("TEST", "Album Name : " + data.getArtistName());
			 Log.d("TEST", "Track ID : "   + data.getTrackId());

			 /*System.out.println("AlbumID : "    + data.getAlbumId());
		        System.out.println("Album Name : " + data.getAlbumName());
		        System.out.println("Artist ID : "  + data.getArtistId());
		        System.out.println("Album Name : " + data.getArtistName());
		        System.out.println("Track ID : "   + data.getTrackId());*/
		} catch (MusixMatchException e) {
			e.printStackTrace();
		}

		
		//  getting Lyrics
         
		int trackID = data.getTrackId();

/*		Lyrics lyrics;
		try {
			lyrics = musixMatch.getLyrics(trackID);
			System.out.println("Lyrics ID       : "     + lyrics.getLyricsId());
			System.out.println("Lyrics Language : "     + lyrics.getLyricsLang());
			System.out.println("Lyrics Body     : "     + lyrics.getLyricsBody());
			System.out.println("Script-Tracking-URL : " + lyrics.getScriptTrackingURL());
			System.out.println("Pixel-Tracking-URL : "  + lyrics.getPixelTrackingURL());
			System.out.println("Lyrics Copyright : "    + lyrics.getLyricsCopyright());
	
		} catch (MusixMatchException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} */
	
		
		// Getting Subtitles 
		
		//int trackID = data.getTrackId();

		Subtitle subtitles;
		try {
			subtitles= musixMatch.getSubtitles(trackID);
			
			if(subtitles != null) {
			
				System.out.println("Subtitles ID       : "     + subtitles.subtitle_id);
				System.out.println("Subtitles Language : "     + subtitles.subtitle_language);
				System.out.println("Subtitles Body     : "     + subtitles.subtitle_body);
				System.out.println("Script-Tracking-URL : " + subtitles.script_tracking_url);
				System.out.println("Pixel-Tracking-URL : "  + subtitles.pixel_tracking_url);
				System.out.println("Lyrics Copyright : "    + subtitles.lyrics_copyright);
			}
			
	
		} catch (MusixMatchException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		//  Searching Tracks 
		
	/*	List<Track> tracks = null;
		try {
			tracks = musixMatch.searchTracks("", "Eminem", "", 10, 10, true);
		} catch (MusixMatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (Track trk : tracks) {
		    TrackData trkData = trk.getTrack();

		    System.out.println("AlbumID : "    + trkData.getAlbumId());
		    System.out.println("Album Name : " + trkData.getAlbumName());
		    System.out.println("Artist ID : "  + trkData.getArtistId());
		    System.out.println("Album Name : " + trkData.getArtistName());
		    System.out.println("Track ID : "   + trkData.getTrackId());
		    System.out.println();
		}*/
   
	
		
}
}