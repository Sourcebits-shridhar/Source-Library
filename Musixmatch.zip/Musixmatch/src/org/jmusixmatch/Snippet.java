package org.jmusixmatch;

public class Snippet {
	
}

