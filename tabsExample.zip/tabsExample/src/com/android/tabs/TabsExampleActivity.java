package com.android.tabs;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class TabsExampleActivity extends TabActivity {
	LayoutInflater layoutInflater = null;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        TabHost tabHost = getTabHost();
        LinearLayout tab1Layout = (LinearLayout) layoutInflater.inflate(R.layout.tab1header, null);
        LinearLayout tab2Layout = (LinearLayout) layoutInflater.inflate(R.layout.tab2header, null);
        TabHost.TabSpec tab1spec = tabHost.newTabSpec("tabOneSpec");
        
        ImageView imgView = new ImageView(this);
        imgView.setBackgroundResource(R.drawable.camerascategory);
        tab1spec.setIndicator("Cameras", imgView.getBackground());
        
        //tab1spec.setContent(R.id.tab1);
        tab1spec.setContent(new TabContentLayout());
        TabHost.TabSpec tab2spec = tabHost.newTabSpec("tabTwoSpec");
        tab2spec.setContent(new TabContentLayout());
        ImageView imgView1 = new ImageView(this);
        imgView1.setBackgroundResource(R.drawable.cupboards);
        tab2spec.setIndicator("Cup Boards", imgView1.getBackground());
        
        
        tabHost.addTab(tab1spec);
        tabHost.addTab(tab2spec);
    }
    private class TabContentLayout implements TabHost.TabContentFactory {

		@Override
		public View createTabContent(String tag) {
			View view = null;
			if(tag.equals("tabOneSpec")) {
				view = (LinearLayout) layoutInflater.inflate(R.layout.tab1layout, null);
			}
			if(tag.equals("tabTwoSpec")) {
				view = (LinearLayout) layoutInflater.inflate(R.layout.tab2layout, null);
			}
			return view;
		}
    	
    }
}
