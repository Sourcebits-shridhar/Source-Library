package com.demo.mediaplr;

import java.io.IOException;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.os.Bundle;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;

public class SurfacePlayerActivity extends Activity  implements
OnCompletionListener, OnPreparedListener, OnVideoSizeChangedListener,
OnErrorListener, SurfaceHolder.Callback, OnTouchListener{
	
	private MediaPlayer mMediaPlayer;
	private SurfaceView mPreview;
	private SurfaceHolder mHolder;
	//private String mCurrentVideoPath = Environment.getExternalStorageDirectory()+"/Karaoke_SB/Taylor Swift.mp4";
	private String mCurrentVideoPath = Environment.getExternalStorageDirectory()+"/Karaoke_SB/video.mp4";
	
	
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
    	mMediaPlayer = new MediaPlayer();

		mMediaPlayer.setOnCompletionListener(this);
		mMediaPlayer.setOnPreparedListener(this);
		mMediaPlayer.setOnVideoSizeChangedListener(this);
		mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
		

		mPreview = (SurfaceView) findViewById(R.id.surface);
		mPreview.setOnTouchListener(this);
		mHolder = mPreview.getHolder();
		mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		mHolder.addCallback(this);

        
    }
    
    private void playVideo(String currentPath) {

		try {
			/*
			 * if (mMediaPlayer.isPlaying()) { mMediaPlayer.stop(); wasPlaying =
			 * true; mMediaPlayer.release(); mMediaPlayer = new MediaPlayer(); }
			 * else { wasPlaying = false; } mMediaPlayer.setVolume(0.9f, 0.9f);
			 */

			if (mMediaPlayer != null) {
				mMediaPlayer.setDataSource(mCurrentVideoPath);
				mMediaPlayer.setDisplay(mHolder);
				mMediaPlayer.prepareAsync();

			}
		} catch (IllegalArgumentException e) {

			e.printStackTrace();
		} catch (IllegalStateException e) {

			try {
				mMediaPlayer.setDataSource(mCurrentVideoPath);
			} catch (IllegalArgumentException e1) {
				e1.printStackTrace();
			} catch (IllegalStateException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		playVideo(mCurrentVideoPath);

	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		if (mMediaPlayer != null) {
			mMediaPlayer.stop();
			mMediaPlayer.release();
			mMediaPlayer = null;
		}
	}


	public void onCompletion(MediaPlayer mp) {
		if (mMediaPlayer != null) {
			mMediaPlayer.stop();
			mMediaPlayer.release();
			mMediaPlayer = null;
		}
		finish();

	}
	
	private boolean mIsVideoSizeKnown = false;
	private boolean mIsVideoReadyToBePlayed = false;
	private int mVideoWidth;
	private int mVideoHeight;

	public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
		mIsVideoSizeKnown = true;
		mVideoWidth = 20;
		mVideoHeight = 220;
		if (mIsVideoReadyToBePlayed && mIsVideoSizeKnown) {
			startVideoPlayback();
		}
	}
	
	private void startVideoPlayback() {
		mHolder.setFixedSize(mVideoWidth, mVideoHeight);
		mMediaPlayer.start();
	}

	public boolean onError(MediaPlayer mp, int what, int extra) {
		/*
		 * if(what==100) { mp.create(this, R.raw.dog); mMediaPlayer=mp;
		 * Log.d(TAG,"New Media Player created"); playVideo(mCurrentVideoPath);
		 * }
		 */
		return true;
	}

	private String durationString;

	public void onPrepared(MediaPlayer mp) {
		mIsVideoReadyToBePlayed = true;
		int duration;
		/* if (mIsVideoReadyToBePlayed && mIsVideoSizeKnown) */{
			mHolder.setFixedSize(mVideoWidth, mVideoHeight);
			mMediaPlayer.start();
		}

	}

}