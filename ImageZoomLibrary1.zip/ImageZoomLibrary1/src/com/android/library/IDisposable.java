package com.android.library;

public interface IDisposable {
	void dispose();
}
