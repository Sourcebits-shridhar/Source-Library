package org.cocos2d.opengl;

public class OpenGLViewCantInitException extends Exception {
    public OpenGLViewCantInitException(String reason) {
    }
}
