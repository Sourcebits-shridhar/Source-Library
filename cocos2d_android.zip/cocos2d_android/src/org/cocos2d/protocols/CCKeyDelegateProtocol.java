package org.cocos2d.protocols;

import android.view.KeyEvent;

/*

*/
public interface CCKeyDelegateProtocol {
    public boolean ccKeyDown(int keyCode, KeyEvent event);
    public boolean ccKeyUp(int keyCode, KeyEvent event);
}
//+1-954-919-2120
