package org.cocos2d.types;

public class ccPointSprite {
    public float x;
    public float y;
    // public float size; /// size is not supported via this way, implement it separately
    public ccColor4F colors = new ccColor4F();
    
    public static final int spriteSize = 6;
}
