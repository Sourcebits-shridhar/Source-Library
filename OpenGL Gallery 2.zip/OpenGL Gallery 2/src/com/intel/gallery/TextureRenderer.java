package com.intel.gallery;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.opengl.GLUtils;

public class TextureRenderer {
	private GL10 mGLContext;
	private Context mContext;
	private FloatBuffer mBgTexturesBuffer;
	private static final float SPREAD_IMAGE = 0.20f;
	private static final float FLANK_SPREAD = 0.4f;
	private static final float FRICTION = 10.0f;
	private static final float MAX_SPEED = 4.0f;
	
	
	 private  int[] SAMPLE_IMAGES = new int[] {
	         R.drawable.gallery_photo_1,
	         R.drawable.gallery_photo_2,
	         R.drawable.gallery_photo_3,
	         R.drawable.gallery_photo_4,
	         R.drawable.gallery_photo_5,
	         R.drawable.gallery_photo_6,
	         R.drawable.gallery_photo_7,
	         R.drawable.gallery_photo_8
	 };
	private int mBgTexture;
	private float[] mMatrix;
	
	public TextureRenderer(Context ctx, GL10 gl) {
		// TODO Auto-generated constructor stub
		
		mGLContext = gl;
		mContext  = ctx;
	}

	
	public void imageRenderer(int position, float off) {
		//mInitBackground = false;
		if (SAMPLE_IMAGES[position] != 0) {
            Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), SAMPLE_IMAGES[position]);
            
            Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 230, 230, false);
         //   mBgBitmapId = 0;

			int tmp = 1;
			int w = bitmap.getWidth();
			int h = bitmap.getHeight();
			while (w > tmp || h > tmp) {
				tmp <<= 1;
			}
			
			int width = tmp;
			int height = tmp;
			Bitmap bm = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
			Canvas cv = new Canvas(bm);
			
			int left = (width - w)/10;
			int top = (height - h)/10;
			cv.drawBitmap(scaledBitmap, left, top, new Paint());
			
			GL10 gl = mGLContext;
			
			int[] tex = new int[1];
			gl.glGenTextures(1, tex, 0);
			mBgTexture = tex[0];
			
			gl.glBindTexture(GL10.GL_TEXTURE_2D, mBgTexture);
			gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_LINEAR);
	    	gl.glTexParameterx(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR);
			GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bm, 0);
			
			setBitmapReflection(gl, mBgTexture, off);
	    	
	    	
            bitmap.recycle();
            scaledBitmap.recycle();
			bm.recycle();
						
	        float[] textcoor = new float[] {
	        		(tmp - w) /2.0f / tmp, (tmp - h) / 2.0f / tmp,
	        		(tmp + w) / 2.0f / tmp, (tmp - h) / 2.0f / tmp,
	        		(tmp - w) / 2.0f / tmp, (tmp + h) / 2.0f / tmp,
	        		(tmp + w) / 2.0f / tmp, (tmp + h) / 2.0f / tmp 
	        };
	        mBgTexturesBuffer = makeFloatBuffer(textcoor);
		
		}
	}
	
	private static FloatBuffer makeFloatBuffer(final float[] arr) {
    	ByteBuffer bb = ByteBuffer.allocateDirect(arr.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(arr);
        fb.position(0);
        return fb;
    }
	
	private void setBitmapReflection (GL10 gl, int mTexture,float off){
		
		  if ( mTexture != 0)  {
	            if (mMatrix == null) {
	                mMatrix = new float[16];
	                mMatrix[15] = 1;
	                mMatrix[10] = 1;
	                mMatrix[5] = 1;
	                mMatrix[0] = 1;
	            }

	            float trans =  off *SPREAD_IMAGE;
	            float f =  off *FLANK_SPREAD;
	            if (f > FLANK_SPREAD)
	                f = FLANK_SPREAD;
	            else if (f < -FLANK_SPREAD)
	                f = -FLANK_SPREAD;

	            mMatrix[3] = -f;
	            mMatrix[0] = 1 - Math.abs(f);
	            float sc = 0.38f * mMatrix[0];
	            trans += f * 1;

	            gl.glPushMatrix();
	            gl.glBindTexture(GL10.GL_TEXTURE_2D, mTexture); // bind texture

	            // draw bitmap
	            gl.glTranslatef(trans, 0, 0); // translate the picture to the right position
	            gl.glScalef(sc, sc, 1.0f); // scale the picture
	            gl.glMultMatrixf(mMatrix, 0); // rotate the picture
	            gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);

	            // draw the reflection
	            gl.glTranslatef(0, -2, 0);
	            gl.glScalef(1, -1, 1);
	            gl.glColor4f(1f, 1f, 1f, 0.5f);
	            gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);
	            gl.glColor4f(1, 1, 1, 1);

	            gl.glPopMatrix();
	        }
	}

}
