package com.androidbook.OpenGL;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.opengles.GL10;

import android.content.Context;

public class Circle extends AbstractSingleTexturedRenderer
{
	private Context mContext=null;
	public Circle(Context context) {
		mContext=context;
	}
	
	private void drawCircle(GL10 gl) {
	     
		final int vertexCounter = 120;
	    float vertices[] = new float[vertexCounter * 3];
	    short indices[] = new short[vertexCounter];
	    float radius = 0.1f;
		
	    
	    for (int i = 0; i < vertexCounter * 3; i += 3) {
	        vertices[i] = (float) (radius * Math.cos(Math.toRadians(i)));
	        vertices[i + 1] = 0.0f;
	        vertices[i + 2] = (float) (radius * Math.sin(Math.toRadians(i)));
	     }


	    for (int i = 0; i < vertexCounter; i++) {
	        indices[i] = (short) i;
	     }
	    float colors[] = new float[vertexCounter * 4];
	    for (int i = 0; i < vertexCounter * 4; i += 4) {
	       colors[i] = 1f;
	       colors[i + 1] = 0f;
	       colors[i + 2] = 0f;
	       colors[i + 3] = 1f;
	    }

	      ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
	      vbb.order(ByteOrder.nativeOrder());
	      FloatBuffer vertexBuffer = vbb.asFloatBuffer();
	      vertexBuffer.put(vertices);
	      vertexBuffer.position(0);

	      ByteBuffer ibb = ByteBuffer.allocateDirect(indices.length * 2);
	      ibb.order(ByteOrder.nativeOrder());
	      ShortBuffer indexBuffer = ibb.asShortBuffer();
	      indexBuffer.put(indices);
	      indexBuffer.position(0);

	      ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length * 4);
	      cbb.order(ByteOrder.nativeOrder());
	      FloatBuffer colorBuffer = cbb.asFloatBuffer();
	      colorBuffer.put(colors);
	      colorBuffer.position(0);

	      gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);

	      gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);

	      gl.glEnableClientState(GL10.GL_COLOR_ARRAY);

	      gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuffer);

	      gl.glDrawElements(GL10.GL_LINE_LOOP, indices.length, GL10.GL_UNSIGNED_SHORT, indexBuffer);

	      gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);

	      gl.glDisableClientState(GL10.GL_COLOR_ARRAY);
	   }

	@Override
	protected void draw(GL10 gl) {
		drawCircle(gl);
		
	}

	
}