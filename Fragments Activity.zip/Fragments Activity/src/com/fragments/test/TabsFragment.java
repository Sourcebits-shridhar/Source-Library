package com.fragments.test;

import org.codeandmagic.android.R;

import android.app.Fragment;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;

public class TabsFragment extends Fragment implements OnTabChangeListener{

	
	private View mRoot;
	private TabHost tabHost;
	
	@Override
	public void onTabChanged(String tabId) {
		// TODO Auto-generated method stub
		
	}

	public void setUpTabs() {
		
		Resources res = getResources(); 
	  
	    TabHost.TabSpec spec;  
	    Intent intent; 

	    intent = new Intent(getActivity(), ListTabActivityGroup.class);
	    spec = tabHost.newTabSpec("finalList").setIndicator("List View",
	                      res.getDrawable(R.drawable.ic_launcher))
	                  .setContent(intent);
	    tabHost.addTab(spec);

	    intent = new Intent(getActivity(), MapViewActivity.class);
	    spec = tabHost.newTabSpec("mapView").setIndicator("Map View",
	                      res.getDrawable(R.drawable.ic_launcher))
	                  .setContent(intent);
	    tabHost.addTab(spec);

	    tabHost.setCurrentTab(0);		
		
	}
	private void setupTabs() {
		mTabHost.setup(); // important!
		mTabHost.addTab(newTab(TAB_WORDS, R.string.tab_words, R.id.tab_1));
		mTabHost.addTab(newTab(TAB_NUMBERS, R.string.tab_numbers, R.id.tab_2));
		mTabHost.addTab(newTab("ANIMALS", R.string.tab_animals, R.id.tab_3));
		mTabHost.addTab(newTab("BIRDS", R.string.tab_birds, R.id.tab_4));
		
		
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setRetainInstance(true);

		tabHost.setOnTabChangedListener(this);
		tabHost.setCurrentTab(0);
		// manually start loading stuff in the first tab
		//updateTab(TAB_WORDS, R.id.tab_1);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mRoot = inflater.inflate(R.layout.fragments, null);
		tabHost = (TabHost) mRoot.findViewById(android.R.id.tabhost);
		setupTabs();
		return mRoot;
	}
	
}
