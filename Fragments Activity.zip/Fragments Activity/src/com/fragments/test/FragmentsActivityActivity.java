package com.fragments.test;



import android.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public class FragmentsActivityActivity extends FragmentActivity {
 
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
	}
    
}