package com.fragments.test;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ListTabActivityGroup extends ActivityGroup {

	public static ListTabActivityGroup group;
	
	private ArrayList<View> history;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		history = new ArrayList<View>();
		group = this;
		
		View view = getLocalActivityManager().startActivity(
				"SearchListActivity",
				new Intent(this, SearchListActivity.class)
						.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
				.getDecorView();

		replaceView(view);
	}
	
	
	public void replaceView(View view) {
	
		history.add(view);
		setContentView(view);
	}

	public void back() {
		
		if(history.size() > 0) {
			
			history.remove(history.size()-1);
			setContentView(history.get(history.size()-1));
		} else {
			finish();
		}
	}
	
	@Override
	public void onBackPressed() {
		
		ListTabActivityGroup.group.back();
		return;
	}
}
